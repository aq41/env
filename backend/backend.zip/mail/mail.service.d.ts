import { User } from 'src/users/users.model';
import { GetAllMessagesDto } from './dto/get-all-messages.dto';
import { GetMessageDto } from './dto/get-message.dto';
import { NewMessageDto } from './dto/new-message.dto';
import { Message } from './mail.model';
export declare class MailService {
    private mailRepository;
    private userRepository;
    constructor(mailRepository: typeof Message, userRepository: typeof User);
    getAllMessages(dto: GetAllMessagesDto): Promise<Message[]>;
    getMessage(dto: GetMessageDto): Promise<Message>;
    newMessage(dto: NewMessageDto): Promise<Message>;
}

import { GetAllMessagesDto } from './dto/get-all-messages.dto';
import { GetMessageDto } from './dto/get-message.dto';
import { NewMessageDto } from './dto/new-message.dto';
import { MailService } from './mail.service';
export declare class MailController {
    private readonly mailService;
    constructor(mailService: MailService);
    getAllMessages(dto: GetAllMessagesDto): Promise<import("./mail.model").Message[]>;
    getMessage(dto: GetMessageDto): Promise<import("./mail.model").Message>;
    newMessage(dto: NewMessageDto): Promise<import("./mail.model").Message>;
}

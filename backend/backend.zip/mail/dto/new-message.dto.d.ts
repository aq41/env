export declare class NewMessageDto {
    readonly senderId: number;
    readonly receiverId: number;
    readonly topic: string;
    readonly message: string;
}

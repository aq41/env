export declare class GetAllMessagesDto {
    readonly auth: string;
}

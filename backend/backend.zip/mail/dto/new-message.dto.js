"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NewMessageDto = void 0;
class NewMessageDto {
}
exports.NewMessageDto = NewMessageDto;
//# sourceMappingURL=new-message.dto.js.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GetAllMessagesDto = void 0;
class GetAllMessagesDto {
}
exports.GetAllMessagesDto = GetAllMessagesDto;
//# sourceMappingURL=get-all-messages.dto.js.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GetMessageDto = void 0;
class GetMessageDto {
}
exports.GetMessageDto = GetMessageDto;
//# sourceMappingURL=get-message.dto.js.map
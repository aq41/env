export declare class GetMessageDto {
    readonly messageId: number;
}

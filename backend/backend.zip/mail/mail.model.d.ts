import { Model } from 'sequelize-typescript';
import { User } from 'src/users/users.model';
interface MessageAttrs {
    topic: string;
    body: string;
    senderId: number;
    receiverId: number;
}
export declare class Message extends Model<Message, MessageAttrs> {
    messageId: number;
    topic: string;
    message: string;
    SenderId: User;
    ReceiverId: User;
}
export {};

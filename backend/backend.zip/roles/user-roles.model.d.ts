import { Model } from 'sequelize-typescript';
export declare class UserRoles extends Model<UserRoles> {
    relId: number;
    roleId: number;
    userId: number;
}

import { Model } from 'sequelize-typescript';
import { User } from 'src/users/users.model';
interface RoleAttrs {
    roleId: number;
}
export declare class Role extends Model<Role, RoleAttrs> {
    roleId: number;
    name: string;
    users: User[];
}
export {};

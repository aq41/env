export declare class RolesModule {
}

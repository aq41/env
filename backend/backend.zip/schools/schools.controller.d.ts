import { IdDto } from './dto/id.dto';
import { SchoolsService } from './schools.service';
export declare class SchoolsController {
    private schoolService;
    constructor(schoolService: SchoolsService);
    getSchoolNameToken(dto: IdDto): Promise<import("./school.model").School>;
}

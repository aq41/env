"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IdDto = void 0;
class IdDto {
}
exports.IdDto = IdDto;
//# sourceMappingURL=id.dto.js.map
export declare class IdDto {
    readonly auth: string;
}

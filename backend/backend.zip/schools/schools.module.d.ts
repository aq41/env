export declare class SchoolsModule {
}

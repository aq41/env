import { User } from 'src/users/users.model';
import { IdDto } from './dto/id.dto';
import { School } from './school.model';
export declare class SchoolsService {
    private userRepository;
    private schoolRepository;
    constructor(userRepository: typeof User, schoolRepository: typeof School);
    getSchoolNameToken(dto: IdDto): Promise<School>;
}

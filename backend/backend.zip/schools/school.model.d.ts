import { Model } from 'sequelize-typescript';
interface SchoolCreationAttrs {
    name: string;
}
export declare class School extends Model<School, SchoolCreationAttrs> {
    schoolId: number;
    name: string;
}
export {};

import { AddOutageDto } from './dto/add-outage.dto';
import { DeleteOutageDto } from './dto/delete-outage.dto';
import { Outage } from './outages.model';
export declare class OutagesService {
    private outageRepository;
    constructor(outageRepository: typeof Outage);
    getOutages(): Promise<Outage[]>;
    addOutage(dto: AddOutageDto): Promise<Outage>;
    deleteOutage(dto: DeleteOutageDto): Promise<number>;
}

import { Model } from 'sequelize-typescript';
interface OutageAttrs {
    outageId: number;
    date: Date;
    affected: string;
    description: string;
}
export declare class Outage extends Model<Outage, OutageAttrs> {
    outageId: number;
    date: Date;
    affected: string;
    description: string;
}
export {};

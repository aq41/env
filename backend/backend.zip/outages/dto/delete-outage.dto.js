"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeleteOutageDto = void 0;
class DeleteOutageDto {
}
exports.DeleteOutageDto = DeleteOutageDto;
//# sourceMappingURL=delete-outage.dto.js.map
export declare class AddOutageDto {
    readonly date: Date;
    readonly affected: string;
    readonly description: string;
}

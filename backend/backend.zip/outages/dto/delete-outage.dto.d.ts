export declare class DeleteOutageDto {
    readonly outageId: number;
}

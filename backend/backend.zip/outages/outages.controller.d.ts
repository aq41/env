import { AddOutageDto } from './dto/add-outage.dto';
import { DeleteOutageDto } from './dto/delete-outage.dto';
import { OutagesService } from './outages.service';
export declare class OutagesController {
    private readonly outagesService;
    constructor(outagesService: OutagesService);
    getOutages(): Promise<import("./outages.model").Outage[]>;
    addOutage(dto: AddOutageDto): Promise<import("./outages.model").Outage>;
    deleteOutage(dto: DeleteOutageDto): Promise<number>;
}

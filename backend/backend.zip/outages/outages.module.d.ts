export declare class OutagesModule {
}

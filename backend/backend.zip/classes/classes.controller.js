"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClassesController = void 0;
const common_1 = require("@nestjs/common");
const common_2 = require("@nestjs/common");
const auth_guard_1 = require("../auth/auth.guard");
const classes_service_1 = require("./classes.service");
const get_class_by_auth_dto_1 = require("./dto/get-class-by-auth.dto");
const get_class_by_id_dto_1 = require("./dto/get-class-by-id.dto");
const set_class_by_auth_dto_1 = require("./dto/set-class-by-auth.dto");
const set_class_by_id_dto_1 = require("./dto/set-class-by-id.dto");
let ClassesController = class ClassesController {
    constructor(classesService) {
        this.classesService = classesService;
    }
    getClassById(dto) {
        return this.classesService.getClassById(dto);
    }
    getClassByAuth(dto) {
        return this.classesService.getClassByAuth(dto);
    }
    setClassById(dto) {
        return this.classesService.setClassById(dto);
    }
    setClassByAuth(dto) {
        return this.classesService.setClassByAuth(dto);
    }
};
__decorate([
    (0, common_1.Post)('/getClassById'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [get_class_by_id_dto_1.GetClassByIdDto]),
    __metadata("design:returntype", void 0)
], ClassesController.prototype, "getClassById", null);
__decorate([
    (0, common_1.Post)('/getClassByAuth'),
    __param(0, (0, common_1.Headers)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [get_class_by_auth_dto_1.GetClassByAuthDto]),
    __metadata("design:returntype", void 0)
], ClassesController.prototype, "getClassByAuth", null);
__decorate([
    (0, common_1.Post)('/setClassById'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [set_class_by_id_dto_1.SetClassByIdDto]),
    __metadata("design:returntype", void 0)
], ClassesController.prototype, "setClassById", null);
__decorate([
    (0, common_1.Post)('/setClassByAuth'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [set_class_by_auth_dto_1.SetClassByAuthDto]),
    __metadata("design:returntype", void 0)
], ClassesController.prototype, "setClassByAuth", null);
ClassesController = __decorate([
    (0, common_1.Controller)('classes'),
    (0, common_2.UseGuards)(auth_guard_1.TokenAuthGuard),
    __metadata("design:paramtypes", [classes_service_1.ClassesService])
], ClassesController);
exports.ClassesController = ClassesController;
//# sourceMappingURL=classes.controller.js.map
import { User } from 'src/users/users.model';
import { Class } from './classes.model';
import { GetClassByAuthDto } from './dto/get-class-by-auth.dto';
import { GetClassByIdDto } from './dto/get-class-by-id.dto';
import { SetClassByAuthDto } from './dto/set-class-by-auth.dto';
import { SetClassByIdDto } from './dto/set-class-by-id.dto';
import { UserClasses } from './user-classes.model';
export declare class ClassesService {
    private ucRepository;
    private userRepository;
    private classRepository;
    constructor(ucRepository: typeof UserClasses, userRepository: typeof User, classRepository: typeof Class);
    getClassById(dto: GetClassByIdDto): Promise<UserClasses>;
    getClassByAuth(dto: GetClassByAuthDto): Promise<Class>;
    setClassById(dto: SetClassByIdDto): Promise<void>;
    setClassByAuth(dto: SetClassByAuthDto): Promise<void>;
}

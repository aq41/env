import { ClassesService } from './classes.service';
import { GetClassByAuthDto } from './dto/get-class-by-auth.dto';
import { GetClassByIdDto } from './dto/get-class-by-id.dto';
import { SetClassByAuthDto } from './dto/set-class-by-auth.dto';
import { SetClassByIdDto } from './dto/set-class-by-id.dto';
export declare class ClassesController {
    private classesService;
    constructor(classesService: ClassesService);
    getClassById(dto: GetClassByIdDto): Promise<import("./user-classes.model").UserClasses>;
    getClassByAuth(dto: GetClassByAuthDto): Promise<import("./classes.model").Class>;
    setClassById(dto: SetClassByIdDto): Promise<void>;
    setClassByAuth(dto: SetClassByAuthDto): Promise<void>;
}

import { Model } from 'sequelize-typescript';
export declare class UserClasses extends Model<UserClasses> {
    relId: number;
    classId: number;
    userId: number;
}

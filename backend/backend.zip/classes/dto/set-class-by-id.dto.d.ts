export declare class SetClassByIdDto {
    readonly userId: number;
    readonly classId?: number;
    readonly classLetter?: string;
    readonly classNumber?: number;
}

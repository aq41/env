export declare class GetClassByAuthDto {
    readonly auth: string;
}

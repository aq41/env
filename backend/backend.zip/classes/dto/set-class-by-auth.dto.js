"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SetClassByAuthDto = void 0;
class SetClassByAuthDto {
}
exports.SetClassByAuthDto = SetClassByAuthDto;
//# sourceMappingURL=set-class-by-auth.dto.js.map
export declare class GetClassByIdDto {
    readonly userId: number;
}

export declare class SetClassByAuthDto {
    readonly auth: string;
    readonly classId?: number;
    readonly classLetter?: string;
    readonly classNumber?: number;
}

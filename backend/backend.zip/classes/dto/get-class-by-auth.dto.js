"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GetClassByAuthDto = void 0;
class GetClassByAuthDto {
}
exports.GetClassByAuthDto = GetClassByAuthDto;
//# sourceMappingURL=get-class-by-auth.dto.js.map
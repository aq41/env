"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SetClassByIdDto = void 0;
class SetClassByIdDto {
}
exports.SetClassByIdDto = SetClassByIdDto;
//# sourceMappingURL=set-class-by-id.dto.js.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GetClassByIdDto = void 0;
class GetClassByIdDto {
}
exports.GetClassByIdDto = GetClassByIdDto;
//# sourceMappingURL=get-class-by-id.dto.js.map
export declare class ClassesModule {
}

import { Model } from 'sequelize-typescript';
import { Plan } from '../education_plan/education_plan.model';
interface ClassAttrs {
    classId: number;
    class_number: number;
    class_letter: string;
}
export declare class Class extends Model<Class, ClassAttrs> {
    classId: number;
    class_number: number;
    class_letter: string;
    plans: Plan[];
}
export {};

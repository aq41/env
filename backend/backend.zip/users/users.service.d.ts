import { CreateUserDto } from './dto/create-user.dto';
import { User } from './users.model';
import { FindTokenDto } from './dto/find-token.dto';
import { UserRoles } from '../roles/user-roles.model';
import { Role } from '../roles/roles.model';
import { FindByIdDto } from './dto/find-by-id.dto';
export declare class UsersService {
    private userRepository;
    private userRolesRepository;
    private rolesRepository;
    constructor(userRepository: typeof User, userRolesRepository: typeof UserRoles, rolesRepository: typeof Role);
    createUser(dto: CreateUserDto): Promise<User>;
    findUserByToken(dto: FindTokenDto): Promise<User>;
    getUserRole(dto: FindTokenDto): Promise<Role>;
    findById(dto: FindByIdDto): Promise<User>;
    getAllUsers(): Promise<User[]>;
    savePersonalSettings(file: any, body: any): Promise<number>;
}

import { Model } from 'sequelize-typescript';
interface UserCreationAttrs {
    name: string;
    password: string;
    creatorId: number;
    SchoolId: number;
    role: string;
}
export declare class User extends Model<User, UserCreationAttrs> {
    userId: number;
    login: string;
    name: string;
    phone: string;
    password: string;
    auth: string;
    photo: Blob;
    SchoolId: number;
}
export {};

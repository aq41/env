"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FindTokenDto = void 0;
class FindTokenDto {
}
exports.FindTokenDto = FindTokenDto;
//# sourceMappingURL=find-token.dto.js.map
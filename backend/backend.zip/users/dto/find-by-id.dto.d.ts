export declare class FindByIdDto {
    readonly userId: number;
}

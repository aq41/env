"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FindByIdDto = void 0;
class FindByIdDto {
}
exports.FindByIdDto = FindByIdDto;
//# sourceMappingURL=find-by-id.dto.js.map
export declare class FindTokenDto {
    readonly auth: string;
}

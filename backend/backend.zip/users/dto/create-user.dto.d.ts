export declare class CreateUserDto {
    readonly name: string;
    readonly password: string;
    readonly creatorId: number;
    readonly schoolId: number;
    readonly role: string;
    auth: string;
}

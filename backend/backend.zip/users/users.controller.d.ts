import { CreateUserDto } from './dto/create-user.dto';
import { FindByIdDto } from './dto/find-by-id.dto';
import { FindTokenDto } from './dto/find-token.dto';
import { UsersService } from './users.service';
export declare class UsersController {
    private usersService;
    constructor(usersService: UsersService);
    create(userDto: CreateUserDto): Promise<import("./users.model").User>;
    findByToken(dto: FindTokenDto): Promise<import("./users.model").User>;
    getRoleByAuth(dto: FindTokenDto): Promise<import("../roles/roles.model").Role>;
    findById(dto: FindByIdDto): Promise<import("./users.model").User>;
    getAllUsers(): Promise<import("./users.model").User[]>;
    savePersonalSettings(file: any, body: any): Promise<number>;
}

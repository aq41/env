"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FactsController = void 0;
const common_1 = require("@nestjs/common");
const create_fact_dto_1 = require("./dto/create-fact.dto");
const delete_fact_dto_1 = require("./dto/delete-fact.dto");
const facts_service_1 = require("./facts.service");
const common_2 = require("@nestjs/common");
const auth_guard_1 = require("../auth/auth.guard");
let FactsController = class FactsController {
    constructor(factsService) {
        this.factsService = factsService;
    }
    getRandomFact() {
        return this.factsService.getRandomFact();
    }
    addNewFact(dto) {
        return this.factsService.addNewFact(dto);
    }
    deleteFact(dto) {
        return this.factsService.deleteFact(dto);
    }
};
__decorate([
    (0, common_1.Post)('/getRandomFact'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], FactsController.prototype, "getRandomFact", null);
__decorate([
    (0, common_1.Post)('/addNewFact'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_fact_dto_1.CreateFactDto]),
    __metadata("design:returntype", void 0)
], FactsController.prototype, "addNewFact", null);
__decorate([
    (0, common_1.Post)('/deleteFact'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [delete_fact_dto_1.DeleteFactDto]),
    __metadata("design:returntype", void 0)
], FactsController.prototype, "deleteFact", null);
FactsController = __decorate([
    (0, common_1.Controller)('facts'),
    (0, common_2.UseGuards)(auth_guard_1.TokenAuthGuard),
    __metadata("design:paramtypes", [facts_service_1.FactsService])
], FactsController);
exports.FactsController = FactsController;
//# sourceMappingURL=facts.controller.js.map
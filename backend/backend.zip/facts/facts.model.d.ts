import { Model } from 'sequelize-typescript';
interface FactAttrs {
    factId: number;
    fact: string;
}
export declare class Fact extends Model<Fact, FactAttrs> {
    factId: number;
    fact: string;
}
export {};

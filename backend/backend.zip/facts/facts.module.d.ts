export declare class FactsModule {
}

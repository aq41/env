import { CreateFactDto } from './dto/create-fact.dto';
import { DeleteFactDto } from './dto/delete-fact.dto';
import { FactsService } from './facts.service';
export declare class FactsController {
    private readonly factsService;
    constructor(factsService: FactsService);
    getRandomFact(): Promise<import("./facts.model").Fact>;
    addNewFact(dto: CreateFactDto): Promise<import("./facts.model").Fact>;
    deleteFact(dto: DeleteFactDto): Promise<number>;
}

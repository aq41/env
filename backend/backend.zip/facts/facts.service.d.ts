import { CreateFactDto } from './dto/create-fact.dto';
import { DeleteFactDto } from './dto/delete-fact.dto';
import { Fact } from './facts.model';
export declare class FactsService {
    private factRepository;
    constructor(factRepository: typeof Fact);
    getRandomFact(): Promise<Fact>;
    addNewFact(dto: CreateFactDto): Promise<Fact>;
    deleteFact(dto: DeleteFactDto): Promise<number>;
}

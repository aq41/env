export declare class CreateFactDto {
    readonly fact: string;
}

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeleteFactDto = void 0;
class DeleteFactDto {
}
exports.DeleteFactDto = DeleteFactDto;
//# sourceMappingURL=delete-fact.dto.js.map
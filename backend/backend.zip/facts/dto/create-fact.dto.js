"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateFactDto = void 0;
class CreateFactDto {
}
exports.CreateFactDto = CreateFactDto;
//# sourceMappingURL=create-fact.dto.js.map
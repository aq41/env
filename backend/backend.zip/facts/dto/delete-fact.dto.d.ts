export declare class DeleteFactDto {
    readonly factId: number;
}

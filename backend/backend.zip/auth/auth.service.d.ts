import { User } from 'src/users/users.model';
import { LoginDto } from './dto/login.dto';
export declare class AuthService {
    private userRepository;
    constructor(userRepository: typeof User);
    login(dto: LoginDto, res: any): Promise<void>;
    loginByLogin(login: string, password: string): Promise<User>;
    loginByPhone(login: string, password: string): Promise<User>;
    logout(res: any): Promise<void>;
}

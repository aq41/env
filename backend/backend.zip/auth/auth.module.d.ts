export declare class AuthModule {
}

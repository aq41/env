export declare class LoginDto {
    readonly login: string;
    readonly password: string;
}

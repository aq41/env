export declare class ScheduleModule {
}

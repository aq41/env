import { ScheduleService } from './schedule.service';
export declare class ScheduleController {
    private scheduleService;
    constructor(scheduleService: ScheduleService);
    getByAuth(): {
        monday: {
            name: string;
            homework: string;
            grade: string;
            date: string;
        }[];
        tuesday: {
            name: string;
            homework: string;
            grade: string;
            date: string;
        }[];
        wednesday: {
            name: string;
            homework: string;
            grade: string;
            date: string;
        }[];
        thursday: {
            name: string;
            homework: string;
            grade: string;
            date: string;
        }[];
        friday: {
            name: string;
            homework: string;
            grade: string;
            date: string;
        }[];
        saturday: {
            name: string;
            homework: string;
            grade: string;
            date: string;
        }[];
    };
}

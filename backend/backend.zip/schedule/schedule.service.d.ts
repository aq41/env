export declare class ScheduleService {
}

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScheduleController = void 0;
const common_1 = require("@nestjs/common");
const schedule_service_1 = require("./schedule.service");
const common_2 = require("@nestjs/common");
const auth_guard_1 = require("../auth/auth.guard");
let ScheduleController = class ScheduleController {
    constructor(scheduleService) {
        this.scheduleService = scheduleService;
    }
    getByAuth() {
        return {
            "monday": [
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" }
            ],
            "tuesday": [
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" }
            ],
            "wednesday": [
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" }
            ],
            "thursday": [
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" }
            ],
            "friday": [
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" }
            ],
            "saturday": [
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" },
                { "name": "Русский язык", "homework": "Упр. 10 стр. 84", "grade": "5", "date": "17 января" }
            ]
        };
    }
};
__decorate([
    (0, common_1.Get)('/getByAuth'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ScheduleController.prototype, "getByAuth", null);
ScheduleController = __decorate([
    (0, common_1.Controller)('schedule'),
    (0, common_2.UseGuards)(auth_guard_1.TokenAuthGuard),
    __metadata("design:paramtypes", [schedule_service_1.ScheduleService])
], ScheduleController);
exports.ScheduleController = ScheduleController;
//# sourceMappingURL=schedule.controller.js.map
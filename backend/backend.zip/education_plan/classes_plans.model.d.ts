import { Model } from 'sequelize-typescript';
export declare class ClassesPlans extends Model<ClassesPlans> {
    relId: number;
    planId: number;
    classId: number;
}

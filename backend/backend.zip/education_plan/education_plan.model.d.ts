import { Model } from 'sequelize-typescript';
import { Class } from 'src/classes/classes.model';
interface PlanCreationAttrs {
    planId: number;
    subject: string;
    creatorId: number;
    schoolId: number;
}
export declare class Plan extends Model<Plan, PlanCreationAttrs> {
    planId: number;
    subject: string;
    CreatorId: number;
    SchoolId: number;
    classes: Class[];
}
export {};

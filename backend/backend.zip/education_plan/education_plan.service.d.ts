import { CreatePlanDto } from './dto/create-plan.dto';
import { DeletePlanDto } from './dto/delete-plan.dto';
import { GetAllPlansDto } from './dto/get-all-plans.dto';
import { GetPlanDto } from './dto/get-plan.dto';
import { Plan } from './education_plan.model';
export declare class EducationPlanService {
    private planRepository;
    constructor(planRepository: typeof Plan);
    getAllPlans(dto: GetAllPlansDto): Promise<Plan[]>;
    getPlan(dto: GetPlanDto): Promise<Plan>;
    createPlan(dto: CreatePlanDto): Promise<Plan>;
    deletePlan(dto: DeletePlanDto): Promise<number>;
}

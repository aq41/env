export declare class DeletePlanDto {
    readonly planId: number;
}

export declare class GetPlanDto {
    readonly planId: number;
}

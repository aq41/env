export declare class GetAllPlansDto {
    readonly schoolId: number;
}

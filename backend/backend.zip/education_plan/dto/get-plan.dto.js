"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GetPlanDto = void 0;
class GetPlanDto {
}
exports.GetPlanDto = GetPlanDto;
//# sourceMappingURL=get-plan.dto.js.map
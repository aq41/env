"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreatePlanDto = void 0;
class CreatePlanDto {
}
exports.CreatePlanDto = CreatePlanDto;
//# sourceMappingURL=create-plan.dto.js.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeletePlanDto = void 0;
class DeletePlanDto {
}
exports.DeletePlanDto = DeletePlanDto;
//# sourceMappingURL=delete-plan.dto.js.map
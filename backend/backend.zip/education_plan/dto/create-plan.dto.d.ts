export declare class CreatePlanDto {
    readonly subject: string;
    readonly creatorId: number;
    readonly schoolId: number;
}

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GetAllPlansDto = void 0;
class GetAllPlansDto {
}
exports.GetAllPlansDto = GetAllPlansDto;
//# sourceMappingURL=get-all-plans.dto.js.map
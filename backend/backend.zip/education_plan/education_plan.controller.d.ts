import { CreatePlanDto } from './dto/create-plan.dto';
import { DeletePlanDto } from './dto/delete-plan.dto';
import { GetAllPlansDto } from './dto/get-all-plans.dto';
import { GetPlanDto } from './dto/get-plan.dto';
import { EducationPlanService } from './education_plan.service';
export declare class EducationPlanController {
    private readonly planService;
    constructor(planService: EducationPlanService);
    getAllPlans(dto: GetAllPlansDto): Promise<import("./education_plan.model").Plan[]>;
    getPlan(dto: GetPlanDto): Promise<import("./education_plan.model").Plan>;
    createPlan(dto: CreatePlanDto): Promise<import("./education_plan.model").Plan>;
    deletePlan(dto: DeletePlanDto): Promise<number>;
}

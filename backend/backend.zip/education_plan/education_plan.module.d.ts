export declare class EducationPlanModule {
}

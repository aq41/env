export declare class JournalService {
}

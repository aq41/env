export declare class JournalController {
}

export declare class JournalModule {
}

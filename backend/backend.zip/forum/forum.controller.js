"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ForumController = void 0;
const common_1 = require("@nestjs/common");
const create_topic_dto_1 = require("./dto/create-topic.dto");
const delete_message_dto_1 = require("./dto/delete-message.dto");
const delete_topic_dto_1 = require("./dto/delete-topic.dto");
const get_topic_dto_1 = require("./dto/get-topic.dto");
const post_message_dto_1 = require("./dto/post-message.dto");
const forum_service_1 = require("./forum.service");
const common_2 = require("@nestjs/common");
const auth_guard_1 = require("../auth/auth.guard");
let ForumController = class ForumController {
    constructor(forumService) {
        this.forumService = forumService;
    }
    getAllTopics() {
        return this.forumService.getAllTopics();
    }
    getTopic(dto) {
        return this.forumService.getTopic(dto);
    }
    createNewTopic(dto) {
        return this.forumService.createNewTopic(dto);
    }
    postMessage(dto) {
        return this.forumService.postMessage(dto);
    }
    deleteTopic(dto) {
        return this.forumService.deleteTopic(dto);
    }
    deleteMessage(dto) {
        return this.forumService.deleteMessage(dto);
    }
};
__decorate([
    (0, common_1.Get)('/getAllTopics'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ForumController.prototype, "getAllTopics", null);
__decorate([
    (0, common_1.Get)('/getTopic'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [get_topic_dto_1.GetTopicDto]),
    __metadata("design:returntype", void 0)
], ForumController.prototype, "getTopic", null);
__decorate([
    (0, common_1.Post)('/createNewTopic'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_topic_dto_1.CreateTopicDto]),
    __metadata("design:returntype", void 0)
], ForumController.prototype, "createNewTopic", null);
__decorate([
    (0, common_1.Post)('/postMessage'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [post_message_dto_1.PostMessageDto]),
    __metadata("design:returntype", void 0)
], ForumController.prototype, "postMessage", null);
__decorate([
    (0, common_1.Post)('/deleteTopic'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [delete_topic_dto_1.DeleteTopicDto]),
    __metadata("design:returntype", void 0)
], ForumController.prototype, "deleteTopic", null);
__decorate([
    (0, common_1.Post)('/deleteMessage'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [delete_message_dto_1.DeleteMessageDto]),
    __metadata("design:returntype", void 0)
], ForumController.prototype, "deleteMessage", null);
ForumController = __decorate([
    (0, common_1.Controller)('forum'),
    (0, common_2.UseGuards)(auth_guard_1.TokenAuthGuard),
    __metadata("design:paramtypes", [forum_service_1.ForumService])
], ForumController);
exports.ForumController = ForumController;
//# sourceMappingURL=forum.controller.js.map
import { CreateTopicDto } from './dto/create-topic.dto';
import { DeleteMessageDto } from './dto/delete-message.dto';
import { DeleteTopicDto } from './dto/delete-topic.dto';
import { GetTopicDto } from './dto/get-topic.dto';
import { PostMessageDto } from './dto/post-message.dto';
import { ForumTopic } from './forum.model';
import { ForumMessage } from './topic.model';
export declare class ForumService {
    private topicRepository;
    private messageRepository;
    constructor(topicRepository: typeof ForumTopic, messageRepository: typeof ForumMessage);
    getAllTopics(): Promise<ForumTopic[]>;
    getTopic(dto: GetTopicDto): Promise<ForumMessage[]>;
    createNewTopic(dto: CreateTopicDto): Promise<ForumTopic>;
    postMessage(dto: PostMessageDto): Promise<ForumMessage>;
    deleteTopic(dto: DeleteTopicDto): Promise<number>;
    deleteMessage(dto: DeleteMessageDto): Promise<number>;
}

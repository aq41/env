import { CreateTopicDto } from './dto/create-topic.dto';
import { DeleteMessageDto } from './dto/delete-message.dto';
import { DeleteTopicDto } from './dto/delete-topic.dto';
import { GetTopicDto } from './dto/get-topic.dto';
import { PostMessageDto } from './dto/post-message.dto';
import { ForumService } from './forum.service';
export declare class ForumController {
    private readonly forumService;
    constructor(forumService: ForumService);
    getAllTopics(): Promise<import("./forum.model").ForumTopic[]>;
    getTopic(dto: GetTopicDto): Promise<import("./topic.model").ForumMessage[]>;
    createNewTopic(dto: CreateTopicDto): Promise<import("./forum.model").ForumTopic>;
    postMessage(dto: PostMessageDto): Promise<import("./topic.model").ForumMessage>;
    deleteTopic(dto: DeleteTopicDto): Promise<number>;
    deleteMessage(dto: DeleteMessageDto): Promise<number>;
}

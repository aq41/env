export declare class ForumModule {
}

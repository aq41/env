export declare class CreateTopicDto {
    readonly creatorId: number;
    readonly topic: string;
    readonly message: string;
}

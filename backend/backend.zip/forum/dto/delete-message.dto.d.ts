export declare class DeleteMessageDto {
    readonly messageId: number;
}

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeleteMessageDto = void 0;
class DeleteMessageDto {
}
exports.DeleteMessageDto = DeleteMessageDto;
//# sourceMappingURL=delete-message.dto.js.map
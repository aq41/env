export declare class GetTopicDto {
    readonly topicId: number;
}

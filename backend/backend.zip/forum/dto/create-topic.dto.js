"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateTopicDto = void 0;
class CreateTopicDto {
}
exports.CreateTopicDto = CreateTopicDto;
//# sourceMappingURL=create-topic.dto.js.map
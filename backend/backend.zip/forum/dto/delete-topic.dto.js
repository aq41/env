"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeleteTopicDto = void 0;
class DeleteTopicDto {
}
exports.DeleteTopicDto = DeleteTopicDto;
//# sourceMappingURL=delete-topic.dto.js.map
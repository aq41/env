export declare class PostMessageDto {
    readonly topicId: number;
    readonly creatorId: number;
    readonly message: string;
}

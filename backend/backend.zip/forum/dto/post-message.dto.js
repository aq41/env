"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostMessageDto = void 0;
class PostMessageDto {
}
exports.PostMessageDto = PostMessageDto;
//# sourceMappingURL=post-message.dto.js.map
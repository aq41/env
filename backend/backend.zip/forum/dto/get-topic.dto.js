"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GetTopicDto = void 0;
class GetTopicDto {
}
exports.GetTopicDto = GetTopicDto;
//# sourceMappingURL=get-topic.dto.js.map
export declare class DeleteTopicDto {
    readonly topicId: number;
}

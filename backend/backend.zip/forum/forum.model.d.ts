import { Model } from 'sequelize-typescript';
import { User } from 'src/users/users.model';
interface ForumTopicAttrs {
    topic: string;
    creatorId: number;
}
export declare class ForumTopic extends Model<ForumTopic, ForumTopicAttrs> {
    topicId: number;
    topic: string;
    CreatorId: User;
}
export {};

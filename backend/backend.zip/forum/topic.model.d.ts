import { Model } from 'sequelize-typescript';
import { User } from 'src/users/users.model';
import { ForumTopic } from './forum.model';
interface ForumMessageAttrs {
    topicId: number;
    message: string;
    creatorId: number;
}
export declare class ForumMessage extends Model<ForumMessage, ForumMessageAttrs> {
    messageId: number;
    message: string;
    creatorId: User;
    TopicId: ForumTopic;
}
export {};

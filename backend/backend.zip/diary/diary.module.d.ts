export declare class DiaryModule {
}

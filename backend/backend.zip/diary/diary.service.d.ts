export declare class DiaryService {
}

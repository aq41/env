export declare class DiaryController {
}

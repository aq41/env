"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const sequelize_1 = require("@nestjs/sequelize");
const users_model_1 = require("./users/users.model");
const users_module_1 = require("./users/users.module");
const schools_module_1 = require("./schools/schools.module");
const auth_module_1 = require("./auth/auth.module");
const education_plan_module_1 = require("./education_plan/education_plan.module");
const diary_module_1 = require("./diary/diary.module");
const journal_module_1 = require("./journal/journal.module");
const reports_module_1 = require("./reports/reports.module");
const schedule_module_1 = require("./schedule/schedule.module");
const outages_module_1 = require("./outages/outages.module");
const forum_module_1 = require("./forum/forum.module");
const mail_module_1 = require("./mail/mail.module");
const roles_module_1 = require("./roles/roles.module");
const roles_model_1 = require("./roles/roles.model");
const user_roles_model_1 = require("./roles/user-roles.model");
const school_model_1 = require("./schools/school.model");
const lessons_module_1 = require("./lessons/lessons.module");
const lessons_model_1 = require("./lessons/lessons.model");
const mail_model_1 = require("./mail/mail.model");
const facts_module_1 = require("./facts/facts.module");
const facts_model_1 = require("./facts/facts.model");
const topic_model_1 = require("./forum/topic.model");
const forum_model_1 = require("./forum/forum.model");
const education_plan_model_1 = require("./education_plan/education_plan.model");
const classes_module_1 = require("./classes/classes.module");
const classes_model_1 = require("./classes/classes.model");
const classes_plans_model_1 = require("./education_plan/classes_plans.model");
let AppModule = class AppModule {
};
AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule.forRoot({
                envFilePath: '.env'
            }),
            sequelize_1.SequelizeModule.forRoot({
                dialect: 'mysql',
                host: process.env.MYSQL_HOST,
                port: Number(process.env.MYSQL_PORT),
                username: process.env.MYSQL_USERNAME,
                password: process.env.MYSQL_PASSWORD,
                database: process.env.MYSQL_DATABASE,
                models: [users_model_1.User, roles_model_1.Role, user_roles_model_1.UserRoles, school_model_1.School, lessons_model_1.Lesson, mail_model_1.Message, facts_model_1.Fact, forum_model_1.ForumTopic, topic_model_1.ForumMessage, education_plan_model_1.Plan, classes_model_1.Class, classes_plans_model_1.ClassesPlans],
                autoLoadModels: true,
                synchronize: true
            }),
            users_module_1.UsersModule,
            schools_module_1.SchoolsModule,
            auth_module_1.AuthModule,
            education_plan_module_1.EducationPlanModule,
            diary_module_1.DiaryModule,
            journal_module_1.JournalModule,
            reports_module_1.ReportsModule,
            schedule_module_1.ScheduleModule,
            outages_module_1.OutagesModule,
            forum_module_1.ForumModule,
            mail_module_1.MailModule,
            roles_module_1.RolesModule,
            lessons_module_1.LessonsModule,
            facts_module_1.FactsModule,
            classes_module_1.ClassesModule,
        ],
        controllers: [],
        providers: []
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map
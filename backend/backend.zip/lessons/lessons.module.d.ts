export declare class LessonsModule {
}

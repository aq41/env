export declare class LessonsController {
}

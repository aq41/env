export declare class LessonsService {
    addLessonToPlan(): Promise<void>;
    removeLessonFromPlan(): Promise<void>;
    updateLessonInPlan(): Promise<void>;
}

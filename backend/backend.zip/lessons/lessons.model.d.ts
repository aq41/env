import { Model } from 'sequelize-typescript';
export declare class Lesson extends Model<Lesson> {
    id: number;
    topic: string;
    homework: string;
    authorId: number;
}

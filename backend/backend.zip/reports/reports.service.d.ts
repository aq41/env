export declare class ReportsService {
    resultGrades(): Promise<void>;
    averageYearGrade(): Promise<void>;
    averageGrade(): Promise<void>;
    currentGrades(): Promise<void>;
    journalAccess(): Promise<void>;
    stats(): Promise<void>;
    classRatingGrades(): Promise<void>;
    classRatingAttendance(): Promise<void>;
    studentRatingGrades(): Promise<void>;
    studentRatingAttendance(): Promise<void>;
    averageGradeTA(): Promise<void>;
    averageYearGradeTA(): Promise<void>;
}

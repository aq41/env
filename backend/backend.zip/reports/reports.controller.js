"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReportsController = void 0;
const common_1 = require("@nestjs/common");
const decorators_1 = require("@nestjs/common/decorators");
const auth_guard_1 = require("../auth/auth.guard");
const roles_decorator_1 = require("../roles/roles.decorator");
const reports_service_1 = require("./reports.service");
let ReportsController = class ReportsController {
    constructor(reportsService) {
        this.reportsService = reportsService;
    }
    resultGrades() {
        return this.reportsService.resultGrades();
    }
    averageYearGrade() {
        return this.reportsService.averageYearGrade();
    }
    averageGrade() {
        return this.reportsService.averageGrade();
    }
    currentGrades() {
        return this.reportsService.currentGrades();
    }
    journalAccess() {
        return this.reportsService.journalAccess();
    }
    stats() {
        return this.reportsService.stats();
    }
    classRatingGrades() {
        return this.reportsService.classRatingGrades();
    }
    classRatingAttendance() {
        return this.reportsService.classRatingAttendance();
    }
    studentRatingGrades() {
        return this.reportsService.studentRatingGrades();
    }
    studentRatingAttendance() {
        return this.reportsService.studentRatingAttendance();
    }
    averageGradeTA() {
        return this.reportsService.averageGradeTA();
    }
    averageYearGradeTA() {
        return this.reportsService.averageYearGradeTA();
    }
};
__decorate([
    (0, decorators_1.Get)('/resultGrades'),
    (0, roles_decorator_1.Roles)('Student', 'Parent'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "resultGrades", null);
__decorate([
    (0, decorators_1.Get)('/averageYearGrade'),
    (0, roles_decorator_1.Roles)('Student', 'Parent'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "averageYearGrade", null);
__decorate([
    (0, decorators_1.Get)('/averageGrade'),
    (0, roles_decorator_1.Roles)('Student', 'Parent'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "averageGrade", null);
__decorate([
    (0, decorators_1.Get)('/currentGrades'),
    (0, roles_decorator_1.Roles)('Student', 'Parent'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "currentGrades", null);
__decorate([
    (0, decorators_1.Get)('/journalAccess'),
    (0, roles_decorator_1.Roles)('Student', 'Parent'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "journalAccess", null);
__decorate([
    (0, decorators_1.Get)('/stats'),
    (0, roles_decorator_1.Roles)('Student', 'Parent'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "stats", null);
__decorate([
    (0, decorators_1.Get)('/classRatingGrades'),
    (0, roles_decorator_1.Roles)('Teacher', 'Admin'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "classRatingGrades", null);
__decorate([
    (0, decorators_1.Get)('/classRatingAttendance'),
    (0, roles_decorator_1.Roles)('Teacher', 'Admin'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "classRatingAttendance", null);
__decorate([
    (0, decorators_1.Get)('/studentRatingGrades'),
    (0, roles_decorator_1.Roles)('Teacher', 'Admin'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "studentRatingGrades", null);
__decorate([
    (0, decorators_1.Get)('/studentRatingAttendance'),
    (0, roles_decorator_1.Roles)('Teacher', 'Admin'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "studentRatingAttendance", null);
__decorate([
    (0, decorators_1.Get)('/averageGradeTA'),
    (0, roles_decorator_1.Roles)('Teacher', 'Admin'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "averageGradeTA", null);
__decorate([
    (0, decorators_1.Get)('/averageYearGradeTA'),
    (0, roles_decorator_1.Roles)('Teacher', 'Admin'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "averageYearGradeTA", null);
ReportsController = __decorate([
    (0, common_1.Controller)('reportss'),
    (0, decorators_1.UseGuards)(auth_guard_1.TokenAuthGuard),
    __metadata("design:paramtypes", [reports_service_1.ReportsService])
], ReportsController);
exports.ReportsController = ReportsController;
//# sourceMappingURL=reports.controller.js.map
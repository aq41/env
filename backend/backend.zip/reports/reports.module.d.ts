export declare class ReportsModule {
}
